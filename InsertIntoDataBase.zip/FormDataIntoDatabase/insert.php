<?php
   $connect=mysqli_connect('localhost','root','','testDataBase');
   $name=$_POST['myName'];
   $email=$_POST['myEmail'];
   $pass=$_POST['myPassword'];
   $query="INSERT INTO `userDataBase`(`Name`,`Email`,`Password`) VALUES ('$name','$email','$pass')";   
   $run=mysqli_query($connect,$query);
   if($run){
	    echo "inserted succesfully";
   }
   else{
	   echo "error!";
   }

?>