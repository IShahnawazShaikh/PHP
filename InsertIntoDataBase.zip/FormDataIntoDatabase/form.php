<html>
<head>
   <title>Login Page</title>
   <style>
     .set{
		 margin:100px;
		 
	 }</style>
</head>
<body>
      <div class="set">
     <h3>Submit your data</h3>
   	 <label><br></label>
    <form action="insert.php" method="post">
	 <label>Name:</label>
	 <input type="text" name="myName" required="required">
	 <label><br></label>
	 <label>Email:</label>
      <input type="email" name="myEmail" required="required">
     <label><br></label>
	 <label>Password:</label>
     <input type="password" name="myPassword" required="required">
      <label><br></label>
      <input type="submit" value="submit">  		
	 </form>
	 </div>
</body>
   

</html>