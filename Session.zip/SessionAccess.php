<?php
  session_start();
  if(isset($_SESSION["uname"])){
	echo "welcome".$_SESSION["uname"];
	   
   }
  else{
	  echo "You are not Login";
  }
?>
<h2>
        <a href="logout.php" style="text-decoration:none">Logout</a>
</h2>