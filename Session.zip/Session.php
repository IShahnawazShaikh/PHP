<?php
    session_start();
   if(isset($_SESSION["uname"])){
	   echo "You have already login";
	  exit();  
   }
   
?>
<html>
   <body>
	  <form method="post">
      <table border="1" margin=100px>
		   <tr>
               <td>Username:<input type="text" name="name" placeholder="username"></td>			  
			</tr>
			<tr>
			 <td>Password:<input type="password" name="password" placeholder="password"></td>
			 </tr>
			 <tr align="center"><td><input type="submit" name="sub"></td></tr>
	  </table>
	  </form>
<?php 
         if(isset($_POST['sub'])){
          $_SESSION["uname"]=$_POST['name'];
		  header('location:SessionAccess.php');
		 }
?>

   </body>
</html>
 
